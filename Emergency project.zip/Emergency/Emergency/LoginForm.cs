﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using Oracle.DataAccess.Client;

namespace Emergency
{
    public partial class LoginForm : Form
    {
        //string cs = ConfigurationManager.ConnectionStrings["dbc"].ConnectionString;
        public LoginForm()
        {
            InitializeComponent();
            
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtBoxUserId.Text != "" && txtBoxPassword.Text != "")
            {
               OracleConnection con = new OracleConnection();
               con.ConnectionString = "User ID=HR;Password=HR;DATA SOURCE=XE "; 

                con.Open();
                string sql = "Select * from HR.U_DETAIL";
                OracleDataAdapter adp = new OracleDataAdapter(sql, con);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                OracleCommand command = new OracleCommand(sql, con);
                command.ExecuteNonQuery();

                if (ds.Tables[0].Rows.Count > 0)
                    
                {
                    MessageBox.Show("Login Successful");

                    this.Hide();
                    DashboardForm h = new DashboardForm();
                    h.Show();

                }
                else
                {
                    MessageBox.Show("Login failed");
                }
            }

            else
            {
                MessageBox.Show("Enter login information");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 h = new Form1();
            h.Show();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void Close_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PasswordLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
            