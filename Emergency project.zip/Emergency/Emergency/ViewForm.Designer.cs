﻿
namespace Emergency
{
    partial class ViewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewForm));
            this.Login_Panel = new System.Windows.Forms.Panel();
            this.btnHome = new System.Windows.Forms.Button();
            this.Icon_pictureBox = new System.Windows.Forms.PictureBox();
            this.TheHealingInfirmary_Label = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxPrescription = new System.Windows.Forms.CheckBox();
            this.checkBoxContact = new System.Windows.Forms.CheckBox();
            this.checkBoxList = new System.Windows.Forms.CheckBox();
            this.checkBoxAmbulance = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Submit_button = new System.Windows.Forms.Button();
            this.Login_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Icon_pictureBox)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Login_Panel
            // 
            this.Login_Panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(86)))), ((int)(((byte)(141)))));
            this.Login_Panel.Controls.Add(this.btnHome);
            this.Login_Panel.Controls.Add(this.Icon_pictureBox);
            this.Login_Panel.Controls.Add(this.TheHealingInfirmary_Label);
            this.Login_Panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.Login_Panel.Location = new System.Drawing.Point(0, 0);
            this.Login_Panel.Name = "Login_Panel";
            this.Login_Panel.Size = new System.Drawing.Size(1115, 91);
            this.Login_Panel.TabIndex = 48;
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("HP Simplified", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.LavenderBlush;
            this.btnHome.Location = new System.Drawing.Point(979, 31);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(115, 39);
            this.btnHome.TabIndex = 48;
            this.btnHome.Text = "Back";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // Icon_pictureBox
            // 
            this.Icon_pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Icon_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("Icon_pictureBox.Image")));
            this.Icon_pictureBox.Location = new System.Drawing.Point(25, 12);
            this.Icon_pictureBox.Name = "Icon_pictureBox";
            this.Icon_pictureBox.Size = new System.Drawing.Size(67, 58);
            this.Icon_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Icon_pictureBox.TabIndex = 109;
            this.Icon_pictureBox.TabStop = false;
            // 
            // TheHealingInfirmary_Label
            // 
            this.TheHealingInfirmary_Label.AutoSize = true;
            this.TheHealingInfirmary_Label.Font = new System.Drawing.Font("Century Schoolbook", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TheHealingInfirmary_Label.ForeColor = System.Drawing.Color.Azure;
            this.TheHealingInfirmary_Label.Location = new System.Drawing.Point(98, 24);
            this.TheHealingInfirmary_Label.Name = "TheHealingInfirmary_Label";
            this.TheHealingInfirmary_Label.Size = new System.Drawing.Size(490, 46);
            this.TheHealingInfirmary_Label.TabIndex = 0;
            this.TheHealingInfirmary_Label.Text = "The Healing Infirmary";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.groupBox1.Controls.Add(this.checkBoxPrescription);
            this.groupBox1.Controls.Add(this.checkBoxContact);
            this.groupBox1.Controls.Add(this.checkBoxList);
            this.groupBox1.Controls.Add(this.checkBoxAmbulance);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(54, 198);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(781, 372);
            this.groupBox1.TabIndex = 51;
            this.groupBox1.TabStop = false;
            // 
            // checkBoxPrescription
            // 
            this.checkBoxPrescription.AutoSize = true;
            this.checkBoxPrescription.Font = new System.Drawing.Font("High Tower Text", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxPrescription.ForeColor = System.Drawing.Color.Azure;
            this.checkBoxPrescription.Location = new System.Drawing.Point(218, 276);
            this.checkBoxPrescription.Name = "checkBoxPrescription";
            this.checkBoxPrescription.Size = new System.Drawing.Size(280, 61);
            this.checkBoxPrescription.TabIndex = 3;
            this.checkBoxPrescription.Text = "Prescription";
            this.checkBoxPrescription.UseVisualStyleBackColor = true;
            // 
            // checkBoxContact
            // 
            this.checkBoxContact.AutoSize = true;
            this.checkBoxContact.Font = new System.Drawing.Font("High Tower Text", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxContact.ForeColor = System.Drawing.Color.LavenderBlush;
            this.checkBoxContact.Location = new System.Drawing.Point(218, 21);
            this.checkBoxContact.Name = "checkBoxContact";
            this.checkBoxContact.Size = new System.Drawing.Size(200, 61);
            this.checkBoxContact.TabIndex = 2;
            this.checkBoxContact.Text = "Contact";
            this.checkBoxContact.UseVisualStyleBackColor = true;
            // 
            // checkBoxList
            // 
            this.checkBoxList.AutoSize = true;
            this.checkBoxList.Font = new System.Drawing.Font("High Tower Text", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxList.ForeColor = System.Drawing.Color.LavenderBlush;
            this.checkBoxList.Location = new System.Drawing.Point(218, 198);
            this.checkBoxList.Name = "checkBoxList";
            this.checkBoxList.Size = new System.Drawing.Size(286, 61);
            this.checkBoxList.TabIndex = 1;
            this.checkBoxList.Text = "List of D & N";
            this.checkBoxList.UseVisualStyleBackColor = true;
            // 
            // checkBoxAmbulance
            // 
            this.checkBoxAmbulance.AutoSize = true;
            this.checkBoxAmbulance.Font = new System.Drawing.Font("High Tower Text", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxAmbulance.ForeColor = System.Drawing.Color.Azure;
            this.checkBoxAmbulance.Location = new System.Drawing.Point(218, 110);
            this.checkBoxAmbulance.Name = "checkBoxAmbulance";
            this.checkBoxAmbulance.Size = new System.Drawing.Size(260, 61);
            this.checkBoxAmbulance.TabIndex = 0;
            this.checkBoxAmbulance.Text = "Ambulance";
            this.checkBoxAmbulance.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(44, 117);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 57);
            this.label1.TabIndex = 50;
            this.label1.Text = "View";
            // 
            // Submit_button
            // 
            this.Submit_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(86)))), ((int)(((byte)(141)))));
            this.Submit_button.FlatAppearance.BorderSize = 0;
            this.Submit_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Submit_button.Font = new System.Drawing.Font("HP Simplified", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submit_button.ForeColor = System.Drawing.Color.Azure;
            this.Submit_button.Location = new System.Drawing.Point(889, 383);
            this.Submit_button.Name = "Submit_button";
            this.Submit_button.Size = new System.Drawing.Size(164, 53);
            this.Submit_button.TabIndex = 49;
            this.Submit_button.Text = "Submit";
            this.Submit_button.UseVisualStyleBackColor = false;
            this.Submit_button.Click += new System.EventHandler(this.Submit_button_Click);
            // 
            // ViewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1115, 626);
            this.Controls.Add(this.Login_Panel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Submit_button);
            this.Name = "ViewForm";
            this.Text = "ViewForm";
            this.Load += new System.EventHandler(this.ViewForm_Load);
            this.Login_Panel.ResumeLayout(false);
            this.Login_Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Icon_pictureBox)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel Login_Panel;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.PictureBox Icon_pictureBox;
        private System.Windows.Forms.Label TheHealingInfirmary_Label;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBoxContact;
        private System.Windows.Forms.CheckBox checkBoxList;
        private System.Windows.Forms.CheckBox checkBoxAmbulance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Submit_button;
        private System.Windows.Forms.CheckBox checkBoxPrescription;
    }
}