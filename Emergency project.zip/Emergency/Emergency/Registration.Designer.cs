﻿
namespace Emergency
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration));
            this.label12 = new System.Windows.Forms.Label();
            this.HRemail = new System.Windows.Forms.TextBox();
            this.HRdepartment = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.HRreset = new System.Windows.Forms.Button();
            this.HRsubmit = new System.Windows.Forms.Button();
            this.HRbrowse = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.HRimage = new System.Windows.Forms.PictureBox();
            this.HRgender = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Icon_pictureBox = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Close_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.HRcontact = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.HRbloodgroup = new System.Windows.Forms.ComboBox();
            this.HRname = new System.Windows.Forms.TextBox();
            this.HRid = new System.Windows.Forms.TextBox();
            this.HRage = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.HRimage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icon_pictureBox)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HRage)).BeginInit();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label12.Location = new System.Drawing.Point(16, 451);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 26);
            this.label12.TabIndex = 88;
            this.label12.Text = "EMAIL:";
            // 
            // HRemail
            // 
            this.HRemail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.HRemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HRemail.Location = new System.Drawing.Point(128, 456);
            this.HRemail.Margin = new System.Windows.Forms.Padding(4);
            this.HRemail.Multiline = true;
            this.HRemail.Name = "HRemail";
            this.HRemail.Size = new System.Drawing.Size(205, 28);
            this.HRemail.TabIndex = 87;
            // 
            // HRdepartment
            // 
            this.HRdepartment.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.HRdepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HRdepartment.Location = new System.Drawing.Point(685, 173);
            this.HRdepartment.Margin = new System.Windows.Forms.Padding(4);
            this.HRdepartment.Multiline = true;
            this.HRdepartment.Name = "HRdepartment";
            this.HRdepartment.Size = new System.Drawing.Size(205, 39);
            this.HRdepartment.TabIndex = 86;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label11.Location = new System.Drawing.Point(447, 178);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(159, 26);
            this.label11.TabIndex = 85;
            this.label11.Text = "DEPARTMENT:";
            // 
            // HRreset
            // 
            this.HRreset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(86)))), ((int)(((byte)(141)))));
            this.HRreset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.HRreset.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HRreset.ForeColor = System.Drawing.Color.Azure;
            this.HRreset.Location = new System.Drawing.Point(832, 528);
            this.HRreset.Margin = new System.Windows.Forms.Padding(4);
            this.HRreset.Name = "HRreset";
            this.HRreset.Size = new System.Drawing.Size(139, 51);
            this.HRreset.TabIndex = 84;
            this.HRreset.Text = "RESET";
            this.HRreset.UseVisualStyleBackColor = false;
            // 
            // HRsubmit
            // 
            this.HRsubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(86)))), ((int)(((byte)(141)))));
            this.HRsubmit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.HRsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HRsubmit.ForeColor = System.Drawing.Color.Azure;
            this.HRsubmit.Location = new System.Drawing.Point(562, 532);
            this.HRsubmit.Margin = new System.Windows.Forms.Padding(4);
            this.HRsubmit.Name = "HRsubmit";
            this.HRsubmit.Size = new System.Drawing.Size(132, 47);
            this.HRsubmit.TabIndex = 83;
            this.HRsubmit.Text = "SUBMIT";
            this.HRsubmit.UseVisualStyleBackColor = false;
            // 
            // HRbrowse
            // 
            this.HRbrowse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(86)))), ((int)(((byte)(141)))));
            this.HRbrowse.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.HRbrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HRbrowse.ForeColor = System.Drawing.Color.Azure;
            this.HRbrowse.Location = new System.Drawing.Point(685, 447);
            this.HRbrowse.Margin = new System.Windows.Forms.Padding(4);
            this.HRbrowse.Name = "HRbrowse";
            this.HRbrowse.Size = new System.Drawing.Size(138, 51);
            this.HRbrowse.TabIndex = 82;
            this.HRbrowse.Text = "BROWSE";
            this.HRbrowse.UseVisualStyleBackColor = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label10.Location = new System.Drawing.Point(562, 307);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 26);
            this.label10.TabIndex = 81;
            this.label10.Text = "IMAGE:";
            // 
            // HRimage
            // 
            this.HRimage.Image = ((System.Drawing.Image)(resources.GetObject("HRimage.Image")));
            this.HRimage.Location = new System.Drawing.Point(717, 248);
            this.HRimage.Margin = new System.Windows.Forms.Padding(4);
            this.HRimage.Name = "HRimage";
            this.HRimage.Size = new System.Drawing.Size(199, 171);
            this.HRimage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.HRimage.TabIndex = 80;
            this.HRimage.TabStop = false;
            // 
            // HRgender
            // 
            this.HRgender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HRgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HRgender.FormattingEnabled = true;
            this.HRgender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.HRgender.Location = new System.Drawing.Point(126, 353);
            this.HRgender.Margin = new System.Windows.Forms.Padding(4);
            this.HRgender.Name = "HRgender";
            this.HRgender.Size = new System.Drawing.Size(160, 25);
            this.HRgender.TabIndex = 79;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label2.Location = new System.Drawing.Point(59, 173);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 26);
            this.label2.TabIndex = 67;
            this.label2.Text = "ID:";
            // 
            // Icon_pictureBox
            // 
            this.Icon_pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Icon_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("Icon_pictureBox.Image")));
            this.Icon_pictureBox.Location = new System.Drawing.Point(117, 3);
            this.Icon_pictureBox.Name = "Icon_pictureBox";
            this.Icon_pictureBox.Size = new System.Drawing.Size(104, 106);
            this.Icon_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Icon_pictureBox.TabIndex = 109;
            this.Icon_pictureBox.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label4.Location = new System.Drawing.Point(35, 307);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 26);
            this.label4.TabIndex = 69;
            this.label4.Text = "AGE:";
            // 
            // Close_button
            // 
            this.Close_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Close_button.FlatAppearance.BorderSize = 0;
            this.Close_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Close_button.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Close_button.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Close_button.Location = new System.Drawing.Point(1156, 21);
            this.Close_button.Name = "Close_button";
            this.Close_button.Size = new System.Drawing.Size(57, 54);
            this.Close_button.TabIndex = 6;
            this.Close_button.Text = "X";
            this.Close_button.UseVisualStyleBackColor = true;
            this.Close_button.Click += new System.EventHandler(this.Close_button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Azure;
            this.label1.Location = new System.Drawing.Point(263, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(384, 50);
            this.label1.TabIndex = 1;
            this.label1.Text = "REGISTRATION";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(86)))), ((int)(((byte)(141)))));
            this.panel1.Controls.Add(this.Icon_pictureBox);
            this.panel1.Controls.Add(this.Close_button);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-101, 4);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1236, 119);
            this.panel1.TabIndex = 78;
            // 
            // HRcontact
            // 
            this.HRcontact.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.HRcontact.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HRcontact.Location = new System.Drawing.Point(141, 524);
            this.HRcontact.Margin = new System.Windows.Forms.Padding(4);
            this.HRcontact.Multiline = true;
            this.HRcontact.Name = "HRcontact";
            this.HRcontact.Size = new System.Drawing.Size(256, 34);
            this.HRcontact.TabIndex = 77;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label8.Location = new System.Drawing.Point(13, 532);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 26);
            this.label8.TabIndex = 76;
            this.label8.Text = "CONTACT:";
            // 
            // HRbloodgroup
            // 
            this.HRbloodgroup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HRbloodgroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HRbloodgroup.FormattingEnabled = true;
            this.HRbloodgroup.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.HRbloodgroup.Location = new System.Drawing.Point(165, 404);
            this.HRbloodgroup.Margin = new System.Windows.Forms.Padding(4);
            this.HRbloodgroup.Name = "HRbloodgroup";
            this.HRbloodgroup.Size = new System.Drawing.Size(160, 25);
            this.HRbloodgroup.TabIndex = 75;
            // 
            // HRname
            // 
            this.HRname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.HRname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HRname.Location = new System.Drawing.Point(126, 238);
            this.HRname.Margin = new System.Windows.Forms.Padding(4);
            this.HRname.Multiline = true;
            this.HRname.Name = "HRname";
            this.HRname.Size = new System.Drawing.Size(199, 36);
            this.HRname.TabIndex = 74;
            // 
            // HRid
            // 
            this.HRid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.HRid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HRid.Location = new System.Drawing.Point(120, 173);
            this.HRid.Margin = new System.Windows.Forms.Padding(4);
            this.HRid.Multiline = true;
            this.HRid.Name = "HRid";
            this.HRid.Size = new System.Drawing.Size(205, 30);
            this.HRid.TabIndex = 73;
            // 
            // HRage
            // 
            this.HRage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.HRage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HRage.Location = new System.Drawing.Point(128, 307);
            this.HRage.Margin = new System.Windows.Forms.Padding(4);
            this.HRage.Name = "HRage";
            this.HRage.Size = new System.Drawing.Size(160, 19);
            this.HRage.TabIndex = 72;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label6.Location = new System.Drawing.Point(3, 404);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(166, 26);
            this.label6.TabIndex = 71;
            this.label6.Text = "BLOOD GROUP:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label5.Location = new System.Drawing.Point(16, 353);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 26);
            this.label5.TabIndex = 70;
            this.label5.Text = "GENDER:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label3.Location = new System.Drawing.Point(35, 238);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 26);
            this.label3.TabIndex = 68;
            this.label3.Text = "NAME:";
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1133, 619);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.HRemail);
            this.Controls.Add(this.HRdepartment);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.HRreset);
            this.Controls.Add(this.HRsubmit);
            this.Controls.Add(this.HRbrowse);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.HRimage);
            this.Controls.Add(this.HRgender);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.HRcontact);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.HRbloodgroup);
            this.Controls.Add(this.HRname);
            this.Controls.Add(this.HRid);
            this.Controls.Add(this.HRage);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Name = "Registration";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.HRimage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icon_pictureBox)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HRage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox HRemail;
        private System.Windows.Forms.TextBox HRdepartment;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button HRreset;
        private System.Windows.Forms.Button HRsubmit;
        private System.Windows.Forms.Button HRbrowse;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox HRimage;
        private System.Windows.Forms.ComboBox HRgender;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox Icon_pictureBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Close_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox HRcontact;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox HRbloodgroup;
        private System.Windows.Forms.TextBox HRname;
        private System.Windows.Forms.TextBox HRid;
        private System.Windows.Forms.NumericUpDown HRage;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
    }
}