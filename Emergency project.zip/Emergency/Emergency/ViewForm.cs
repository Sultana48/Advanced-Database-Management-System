﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Emergency
{
    public partial class ViewForm : Form
    {
        string name1 = "Contact";
        string name2 = "Ambulance";
        string name3 = "List of D & N";
        string name4 = "Prescription";
        

        public ViewForm()
        {
            InitializeComponent();
        }

        private void ViewForm_Load(object sender, EventArgs e)
        {

        }

        private void Submit_button_Click(object sender, EventArgs e)
        {
            Submit_button.Enabled = true;


            if (checkBoxContact.Checked == true)
            {
                name1 = checkBoxContact.Text;
                MessageBox.Show(name1 + " ");

                this.Hide();
                ContactForm h = new ContactForm();
                h.Show();

            }
            else
            {
                name1 = "";

            }


            if (checkBoxAmbulance.Checked == true)
            {
                name2 = checkBoxAmbulance.Text;

                MessageBox.Show(name2 + " ");

                this.Hide();
                AmbulanceForm a = new AmbulanceForm();
                a.Show();
            }
            else
            {
                name2 = "";

            }

            if (checkBoxList.Checked == true)
            {
                name3 = checkBoxList.Text;

                MessageBox.Show(name3 + " ");
                this.Hide();
                ListofDoctosNurseForm a = new ListofDoctosNurseForm();
                a.Show();

            }
            else
            {
                name3 = "";

            }

            if (checkBoxPrescription.Checked == true)
            {
                name4 = checkBoxPrescription.Text;
                MessageBox.Show(name4 + " ");

                this.Hide();
                PrescriptionForm h = new PrescriptionForm();
                h.Show();

            }
            else
            {
                name4 = "";

            }

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardForm a3 = new DashboardForm();
            a3.Show();
        }
    }
}
