﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Emergency
{
    public partial class SearchForm : Form
    {
        string name1 = "Contact";
        string name2 = "Ambulance";
        string name3 = "Prescription";
        string name4 = "Medicine";
        public SearchForm()
        {
            InitializeComponent();
        }

        private void Submit_button_Click(object sender, EventArgs e)
        {
            Submit_button.Enabled = true;


            if (checkBoxContact.Checked == true)
            {
                name1 = checkBoxContact.Text;
                MessageBox.Show(name1 + " ");

                this.Hide();
                U_detailSearchForm h = new U_detailSearchForm();
                h.Show();

            }
            else
            {
                name1 = "";

            }


            if (checkBoxAmbulance.Checked == true)
            {
                name2 = checkBoxAmbulance.Text;

                MessageBox.Show(name2 + " ");

                this.Hide();
                SearchAmbulanceForm a = new SearchAmbulanceForm();
                a.Show();
            }
            else
            {
                name2 = "";

            }

            if (checkBoxPrescription.Checked == true)
            {
                name3 = checkBoxPrescription.Text;
                MessageBox.Show(name3 + " ");

                this.Hide();
                SearchPrescriptionForm h = new SearchPrescriptionForm();
                h.Show();

            }
            else
            {
                name3 = "";

            }

            if (checkBox4.Checked == true)
            {
                name4 = checkBox4.Text;
                MessageBox.Show(name4 + " ");

                this.Hide();
                SearchMedicineForm h = new SearchMedicineForm();
                h.Show();

            }
            else
            {
                name3 = "";

            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardForm a3 = new DashboardForm();
            a3.Show();
        }
    }
}
