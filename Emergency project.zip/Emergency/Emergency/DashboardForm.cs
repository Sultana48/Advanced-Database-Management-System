﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace Emergency
{
    public partial class DashboardForm : Form
    {
        public DashboardForm()
        {
            InitializeComponent();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            this.Hide();
            ViewForm h = new ViewForm();
            h.Show();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm h = new LoginForm();
            h.Show();
        }

        private void btnRecords_Click(object sender, EventArgs e)
        {
            this.Hide();
            Record h = new Record();
            h.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            OracleConnection con = new OracleConnection();
            con.ConnectionString = "User ID=HR;Password=HR;DATA SOURCE=XE ";

            con.Open();
            string sql = "EXEC TODAY_IS";
            OracleDataAdapter adp = new OracleDataAdapter(sql, con);
            DataTable ds = new DataTable();
            adp.Fill(ds); 
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.Hide();
            SearchForm h = new SearchForm();
            h.Show();

            /*  this.Hide();
            AmbulanceSearchForm h = new AmbulanceSearchForm();
            h.Show(); */
        }

        private void btnNurseSal_Click(object sender, EventArgs e)
        {
            this.Hide();
            NurseSalaryForm h = new NurseSalaryForm();
            h.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            U_detailSearchForm h = new U_detailSearchForm();
            h.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            SearchPrescriptionForm a = new SearchPrescriptionForm();
            a.Show();
        }
    }
}
