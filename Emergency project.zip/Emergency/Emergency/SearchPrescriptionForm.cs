﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace Emergency
{
    public partial class SearchPrescriptionForm : Form
    {
        int count = 0;
        public SearchPrescriptionForm()
        {
            InitializeComponent();
            BindGridView();

        }
        void BindGridView()
        {
            OracleConnection con = new OracleConnection();
            con.ConnectionString = "User Id=HR;Password=HR;DATA SOURCE=XE ";
            string sql = "Select * from HR.prescription_rec ";

            OracleCommand command = new OracleCommand(sql, con);
            OracleDataAdapter adp = new OracleDataAdapter(sql, con);
            DataTable data = new DataTable();
            adp.Fill(data);
            dataGridView1.DataSource = data;

        }

        public void searchData(string valueToSearch)
        {
            count = 0;
            OracleConnection con = new OracleConnection();
            con.ConnectionString = "User Id=HR;Password=HR;DATA SOURCE=XE ";
            string sql = "select * from HR.prescription_rec WHERE p_id like '%" + valueToSearch + "'";
            OracleCommand command = new OracleCommand(sql, con);
            OracleDataAdapter adp = new OracleDataAdapter(sql, con);
            DataTable table = new DataTable();
            adp.Fill(table);
            dataGridView1.DataSource = table;

            count = Convert.ToInt32(table.Rows.Count.ToString());
            if (count > 0)
            {
                MessageBox.Show("Congrates....Data Found!!! ");


            }
            else
            {
                MessageBox.Show("Sorry..data not found!!!  ");

            }
      }
        private void button1_Click(object sender, EventArgs e)
        {
            string valueToSearch = textBox1.Text.ToString();
            textBox1.Text = "";

            searchData(valueToSearch);
        }

        private void Close_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardForm h = new DashboardForm();
            h.Show();
        }

        private void SearchPrescriptionForm_Load(object sender, EventArgs e)
        {

        }
    }
}
