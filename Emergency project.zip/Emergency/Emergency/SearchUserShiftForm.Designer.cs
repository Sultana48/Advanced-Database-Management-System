﻿
namespace Emergency
{
    partial class SearchUserShiftForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchUserShiftForm));
            this.ViewAppointment_Panel = new System.Windows.Forms.Panel();
            this.AppointmentList_Label = new System.Windows.Forms.Label();
            this.Icon_pictureBox = new System.Windows.Forms.PictureBox();
            this.Home_button = new System.Windows.Forms.Button();
            this.SearchUserShift_dataGridView = new System.Windows.Forms.DataGridView();
            this.Search_textBox = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.ViewAppointment_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Icon_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SearchUserShift_dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ViewAppointment_Panel
            // 
            this.ViewAppointment_Panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(86)))), ((int)(((byte)(141)))));
            this.ViewAppointment_Panel.Controls.Add(this.AppointmentList_Label);
            this.ViewAppointment_Panel.Controls.Add(this.Icon_pictureBox);
            this.ViewAppointment_Panel.Controls.Add(this.Home_button);
            this.ViewAppointment_Panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.ViewAppointment_Panel.Location = new System.Drawing.Point(0, 0);
            this.ViewAppointment_Panel.Name = "ViewAppointment_Panel";
            this.ViewAppointment_Panel.Size = new System.Drawing.Size(1025, 127);
            this.ViewAppointment_Panel.TabIndex = 103;
            // 
            // AppointmentList_Label
            // 
            this.AppointmentList_Label.AutoSize = true;
            this.AppointmentList_Label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AppointmentList_Label.Font = new System.Drawing.Font("Century Schoolbook", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppointmentList_Label.ForeColor = System.Drawing.Color.Azure;
            this.AppointmentList_Label.Location = new System.Drawing.Point(135, 37);
            this.AppointmentList_Label.Name = "AppointmentList_Label";
            this.AppointmentList_Label.Size = new System.Drawing.Size(340, 72);
            this.AppointmentList_Label.TabIndex = 23;
            this.AppointmentList_Label.Text = "User Shift";
            // 
            // Icon_pictureBox
            // 
            this.Icon_pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Icon_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("Icon_pictureBox.Image")));
            this.Icon_pictureBox.Location = new System.Drawing.Point(12, 12);
            this.Icon_pictureBox.Name = "Icon_pictureBox";
            this.Icon_pictureBox.Size = new System.Drawing.Size(104, 106);
            this.Icon_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Icon_pictureBox.TabIndex = 109;
            this.Icon_pictureBox.TabStop = false;
            // 
            // Home_button
            // 
            this.Home_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.Home_button.FlatAppearance.BorderSize = 0;
            this.Home_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Home_button.Font = new System.Drawing.Font("HP Simplified", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home_button.ForeColor = System.Drawing.Color.LavenderBlush;
            this.Home_button.Location = new System.Drawing.Point(889, 37);
            this.Home_button.Name = "Home_button";
            this.Home_button.Size = new System.Drawing.Size(115, 58);
            this.Home_button.TabIndex = 80;
            this.Home_button.Text = "Home";
            this.Home_button.UseVisualStyleBackColor = false;
            // 
            // SearchUserShift_dataGridView
            // 
            this.SearchUserShift_dataGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.SearchUserShift_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SearchUserShift_dataGridView.Location = new System.Drawing.Point(47, 365);
            this.SearchUserShift_dataGridView.Name = "SearchUserShift_dataGridView";
            this.SearchUserShift_dataGridView.RowHeadersWidth = 51;
            this.SearchUserShift_dataGridView.RowTemplate.Height = 24;
            this.SearchUserShift_dataGridView.Size = new System.Drawing.Size(966, 432);
            this.SearchUserShift_dataGridView.TabIndex = 102;
            // 
            // Search_textBox
            // 
            this.Search_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search_textBox.Location = new System.Drawing.Point(147, 289);
            this.Search_textBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Search_textBox.Name = "Search_textBox";
            this.Search_textBox.Size = new System.Drawing.Size(265, 38);
            this.Search_textBox.TabIndex = 104;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(86)))), ((int)(((byte)(141)))));
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Elephant", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.LavenderBlush;
            this.btnSearch.Location = new System.Drawing.Point(451, 272);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(176, 72);
            this.btnSearch.TabIndex = 105;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // SearchUserShiftForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1025, 803);
            this.Controls.Add(this.ViewAppointment_Panel);
            this.Controls.Add(this.SearchUserShift_dataGridView);
            this.Controls.Add(this.Search_textBox);
            this.Controls.Add(this.btnSearch);
            this.Name = "SearchUserShiftForm";
            this.Text = "SearchUserShiftForm";
            this.Load += new System.EventHandler(this.SearchUserShiftForm_Load);
            this.ViewAppointment_Panel.ResumeLayout(false);
            this.ViewAppointment_Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Icon_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SearchUserShift_dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel ViewAppointment_Panel;
        private System.Windows.Forms.Label AppointmentList_Label;
        private System.Windows.Forms.PictureBox Icon_pictureBox;
        private System.Windows.Forms.Button Home_button;
        private System.Windows.Forms.DataGridView SearchUserShift_dataGridView;
        private System.Windows.Forms.TextBox Search_textBox;
        private System.Windows.Forms.Button btnSearch;
    }
}