﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace Emergency
{
    public partial class NurseSalaryForm : Form
    {
        public NurseSalaryForm()
        {
            InitializeComponent();
        }

        private void UserIdLabel_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (txtBoxSalary.Text != "")
            {
                /*     string str = "User ID=HR;Password=HR;DATA SOURCE=XE";
                OracleConnection conn = new OracleConnection(str);
                OracleCommand cmd = new OracleCommand("nurse_sal_calc", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("Nurse Id", OracleDbType.Int32, 6).Value = Int32.Parse(txtBoxSalary.Text);
                conn.Open();
                cmd.ExecuteNonQuery(); */





                OracleConnection con = new OracleConnection();
                     con.ConnectionString = "User ID=HR;Password=HR;DATA SOURCE=XE ";
                     con.Open();

                     //string sql = @"BEGIN nurse_sal_calc(); END ";



                     string sql= "exec nurse_sal_calc()";
                     OracleDataAdapter adp = new OracleDataAdapter(sql, con);
                     DataSet ds = new DataSet();
                     adp.Fill(ds);




                     OracleCommand command = new OracleCommand(sql, con);
                     command.ExecuteNonQuery();

                     if (ds.Tables[0].Rows.Count > 0)

                     {
                         MessageBox.Show("Nurse Salary is: ");

                         this.Hide();
                         DashboardForm h = new DashboardForm();
                         h.Show();

                     }
                     else
                     {
                         MessageBox.Show("Login failed");
                     }
                 }
                 else
                 {
                     MessageBox.Show("Enter login information");
                 } 
            }

        private void NurseSalaryForm_Load(object sender, EventArgs e)
        {

        }
    }

    
    }


