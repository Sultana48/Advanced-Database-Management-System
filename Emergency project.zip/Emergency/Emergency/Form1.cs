﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace Emergency
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            BindGridView();
        }
        void BindGridView()
        {
            OracleConnection con = new OracleConnection();
            con.ConnectionString = "User Id=HR;Password=HR;DATA SOURCE=XE ";
            string sql = "Select * from HR.registration ";

            OracleCommand command = new OracleCommand(sql, con);
            OracleDataAdapter adp = new OracleDataAdapter(sql, con);
            DataTable data = new DataTable();
            adp.Fill(data);
            dataGridView1.DataSource = data;

        }

        private void HRsubmit_Click(object sender, EventArgs e)
        {
            OracleConnection con = new OracleConnection();
            con.ConnectionString = "User Id=HR;Password=HR;DATA SOURCE=XE ";
            string sql = "Insert Into HR.registration values(@id,@name,@contact,@mail ) ";
            //
            OracleCommand cmd = new OracleCommand(sql, con);

            cmd.Parameters.Add("@id", OracleDbType.Int32, 6).Value = Int32.Parse(HRid.Text);
            cmd.Parameters.Add("@name", OracleDbType.Varchar2, 25).Value = HRname.Text;
            cmd.Parameters.Add("@contact", OracleDbType.Varchar2, 11).Value = HRcontact.Text;
            cmd.Parameters.Add("@mail", OracleDbType.Varchar2, 25).Value = HRemail.Text;
            con.Open();

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Data Saved Successfully! :) ");

                HRid.Text = ""; ;
                HRname.Text = "";
                HRcontact.Text = "";
                HRemail.Text = "";


                BindGridView();

            }
            else
            {
                MessageBox.Show("Data not Saved ! ");
            }


        }

        private void Close_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm h = new LoginForm();
            h.Show();
        }
    }
}
