﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace Emergency
{
    public partial class PrescriptionForm : Form
    {
        public PrescriptionForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardForm h = new DashboardForm();
            h.Show();
        }

        private void PrescriptionForm_Load(object sender, EventArgs e)
        {
            try
            {
                OracleConnection con = new OracleConnection();
                con.ConnectionString = "User Id=HR;Password=HR;DATA SOURCE=XE ";
                con.Open();
                string sql = "Select * from HR.doc_pr_det";
                OracleDataAdapter adp = new OracleDataAdapter(sql, con);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                OracleCommand command = new OracleCommand(sql, con);
                command.ExecuteNonQuery();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dataGridView1.DataSource = ds.Tables[0];

                }



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
