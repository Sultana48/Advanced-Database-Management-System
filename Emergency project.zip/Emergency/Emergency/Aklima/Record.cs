﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Emergency
{
    public partial class Record : Form
    {
        string name1 = "User Record";
        string name2 = "Prescription Record";
        public Record()
        {
            InitializeComponent();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardForm h = new DashboardForm();
            h.Show();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void Submit_button_Click(object sender, EventArgs e)
        {

            Submit_button.Enabled = true;


            if (checkBox1.Checked == true)
            {
                name1 = checkBox1.Text;
                MessageBox.Show(name1 + " ");

                this.Hide();
                UserRecordForm h = new UserRecordForm();
                h.Show();

            }
            else
            {
                name1 = "";

            }


            if (checkBox2.Checked == true)
            {
                name2 = checkBox2.Text;

                MessageBox.Show(name2 + " ");

                this.Hide();
                PrescriptionRecordForm a = new PrescriptionRecordForm();
                a.Show();
            }
            else
            {
                name2 = "";

            }
        }
    }
}
