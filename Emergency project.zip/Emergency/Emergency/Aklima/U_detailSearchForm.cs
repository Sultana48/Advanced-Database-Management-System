﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace Emergency
{
    public partial class U_detailSearchForm : Form
    {
        public U_detailSearchForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OracleConnection con = new OracleConnection();
            con.ConnectionString = "User Id=HR;Password=HR;DATA SOURCE=XE ";
            string sql = "Select * from HR.u_detail where u_id= " + textBox1.Text;
            //string sql = "select get_complete_details(p_id) from dual " + textBox1.Text;
            OracleCommand command = new OracleCommand(sql, con);
            OracleDataAdapter adp = new OracleDataAdapter(sql, con);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            //command.ExecuteNonQuery();
            if (ds.Tables[0].Rows.Count > 0)
            {
                
                textBox2.Text = ds.Tables[0].Rows[0]["u_pass"].ToString();
                textBox3.Text = ds.Tables[0].Rows[0]["u_name"].ToString();
                textBox4.Text = ds.Tables[0].Rows[0]["u_number"].ToString();
                textBox5.Text = ds.Tables[0].Rows[0]["u_mail"].ToString();
                textBox6.Text = ds.Tables[0].Rows[0]["u_info"].ToString();
                
            }

            else
            {
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
           
            }
            con.Close();


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void U_detailSearchForm_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            SearchForm a = new SearchForm();
            a.Show();
            this.Hide();
        }
    }
}
