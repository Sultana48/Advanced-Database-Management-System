﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace Emergency
{
    public partial class SearchMedicineForm : Form
    {
        public SearchMedicineForm()
        {
            InitializeComponent();
        }

        private void SearchMedicineForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OracleConnection con = new OracleConnection();
            con.ConnectionString = "User Id=HR;Password=HR;DATA SOURCE=XE ";
            string sql = "Select * from HR.MEDICINE where m_id= " + textBox1.Text;
            //string sql = "select get_complete_details(p_id) from dual " + textBox1.Text;
            OracleCommand command = new OracleCommand(sql, con);
            OracleDataAdapter adp = new OracleDataAdapter(sql, con);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            //command.ExecuteNonQuery();
            if (ds.Tables[0].Rows.Count > 0)
            {

                textBox2.Text = ds.Tables[0].Rows[0]["m_name"].ToString();
                textBox3.Text = ds.Tables[0].Rows[0]["m_price"].ToString();
                textBox4.Text = ds.Tables[0].Rows[0]["m_status"].ToString();
                

            }

            else
            {
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                

            }
            con.Close();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardForm h = new DashboardForm();
            h.Show();
        }
    }
}
