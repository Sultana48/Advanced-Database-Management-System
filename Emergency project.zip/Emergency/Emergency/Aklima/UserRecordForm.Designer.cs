﻿
namespace Emergency
{
    partial class UserRecordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserRecordForm));
            this.Login_Panel = new System.Windows.Forms.Panel();
            this.btnHome = new System.Windows.Forms.Button();
            this.Icon_pictureBox = new System.Windows.Forms.PictureBox();
            this.TheHealingInfirmary_Label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Login_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Icon_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Login_Panel
            // 
            this.Login_Panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(86)))), ((int)(((byte)(141)))));
            this.Login_Panel.Controls.Add(this.btnHome);
            this.Login_Panel.Controls.Add(this.Icon_pictureBox);
            this.Login_Panel.Controls.Add(this.TheHealingInfirmary_Label);
            this.Login_Panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.Login_Panel.Location = new System.Drawing.Point(0, 0);
            this.Login_Panel.Margin = new System.Windows.Forms.Padding(2);
            this.Login_Panel.Name = "Login_Panel";
            this.Login_Panel.Size = new System.Drawing.Size(713, 74);
            this.Login_Panel.TabIndex = 51;
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("HP Simplified", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.LavenderBlush;
            this.btnHome.Location = new System.Drawing.Point(607, 20);
            this.btnHome.Margin = new System.Windows.Forms.Padding(2);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(86, 32);
            this.btnHome.TabIndex = 49;
            this.btnHome.Text = "Back";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // Icon_pictureBox
            // 
            this.Icon_pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Icon_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("Icon_pictureBox.Image")));
            this.Icon_pictureBox.Location = new System.Drawing.Point(19, 10);
            this.Icon_pictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.Icon_pictureBox.Name = "Icon_pictureBox";
            this.Icon_pictureBox.Size = new System.Drawing.Size(50, 47);
            this.Icon_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Icon_pictureBox.TabIndex = 109;
            this.Icon_pictureBox.TabStop = false;
            // 
            // TheHealingInfirmary_Label
            // 
            this.TheHealingInfirmary_Label.AutoSize = true;
            this.TheHealingInfirmary_Label.Font = new System.Drawing.Font("Century Schoolbook", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TheHealingInfirmary_Label.ForeColor = System.Drawing.Color.Azure;
            this.TheHealingInfirmary_Label.Location = new System.Drawing.Point(74, 20);
            this.TheHealingInfirmary_Label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TheHealingInfirmary_Label.Name = "TheHealingInfirmary_Label";
            this.TheHealingInfirmary_Label.Size = new System.Drawing.Size(392, 37);
            this.TheHealingInfirmary_Label.TabIndex = 0;
            this.TheHealingInfirmary_Label.Text = "The Healing Infirmary";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Schoolbook", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label3.Location = new System.Drawing.Point(33, 104);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(184, 32);
            this.label3.TabIndex = 52;
            this.label3.Text = "User Record";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Silver;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.Black;
            this.dataGridView1.Location = new System.Drawing.Point(55, 165);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(584, 246);
            this.dataGridView1.TabIndex = 53;
            // 
            // UserRecordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Login_Panel);
            this.Name = "UserRecordForm";
            this.Text = "UserRecordForm";
            this.Load += new System.EventHandler(this.UserRecordForm_Load);
            this.Login_Panel.ResumeLayout(false);
            this.Login_Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Icon_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel Login_Panel;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.PictureBox Icon_pictureBox;
        private System.Windows.Forms.Label TheHealingInfirmary_Label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}