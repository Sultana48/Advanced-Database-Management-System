﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace Emergency
{
    public partial class SearchUserShiftForm : Form
    {
        int count = 0;
        
        public SearchUserShiftForm()
        {
            InitializeComponent();
            BindGridView();
        }
        void BindGridView()
        {
            OracleConnection con = new OracleConnection();
            con.ConnectionString = "User Id=HR;Password=HR;DATA SOURCE=XE ";
            con.Open();
            //string sql = "Select * from exec staff_up ('@user')";

            string sql = "exec staff_up ('@user')";
            OracleDataAdapter adp = new OracleDataAdapter(sql, con);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            SearchUserShift_dataGridView.DataSource = ds;
            OracleCommand command = new OracleCommand(sql, con);
            command.ExecuteNonQuery();
        }

        private void SearchUserShiftForm_Load(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string valueToSearch = Search_textBox.Text.ToString();
            Search_textBox.Text = "";

            searchData(valueToSearch);
        }

        public void searchData(string valueToSearch)
        {
            count = 0;
            OracleConnection con = new OracleConnection();
            string sql = "exec staff_up ('@user')"; ////user shift detail form e
            OracleDataAdapter adp = new OracleDataAdapter(sql, con);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            SearchUserShift_dataGridView.DataSource = ds;

            count = Convert.ToInt32(ds.Tables[0].Rows.Count.ToString());
            if (count > 0)
            {
                MessageBox.Show("Congrates....Data Found!!! ");


            }
            else
            {
                MessageBox.Show("Sorry..data not found!!!  ");

            }
        }
    }
}
